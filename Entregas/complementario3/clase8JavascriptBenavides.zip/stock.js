alert('Bienvenido a la aplicación de stock!');

const stock = new Stock();

document.addEventListener('DOMContentLoaded', () => {
    runStockLoop();
})